/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 10, 2018, 12:44 PM
 * Purpose: Assignment 2 
 */

/*
 Write a program that calculates a car’s gas mileage. The program should ask 
 * the user to enter the number of gallons of gas the car can hold and the 
 * number of miles it can be driven on a full tank. It should then display 
 * the number of miles that may be driven per gallon of gas.
 */

#include <iostream>

using namespace std;


int main() 
{
    float gallons, miles, mpg; 
    
    cout<<"Enter the amount of gallons your car holds: "<<endl; 
    cin>>gallons;
    
    cout<<"Enter the amount of miles your can drive in one full tank: "<<endl; 
    cin>>miles;
    
    mpg=miles/gallons;
    
    cout<<"The miles per gallon this vehicle is: "<<mpg<<" mpg"<<endl;
   
    
          
    return 0;
}

