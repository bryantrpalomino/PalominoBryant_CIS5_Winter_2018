/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 11:06 PM
 * Purpose: Assignment 2
 */


#include <iostream>
#include <iomanip>  
using namespace std;


int main()  
{ 
    //contants 
    float dolYen,dolEur, yenTot, eurTot; 
    
    //statements 
    cout << "How much dollars do you want to convert to Japanese Yen? ";
    cin >> setw(7) >> dolYen;
    cout << "How much dollars do you want to convert to Euros? ";
    cin >> setw(7)>> dolEur;
    
    //Equations  
    yenTot = dolYen * 98.93;        //Dollars to yen 
    
    eurTot = dolEur * 0.74;         //Dollars to Euro's
    
    cout <<"\n$"<< dolYen << " dollars exchanges to ";
    cout<< fixed << setprecision(2) << yenTot << " Japanese Yens."<< endl;
    cout <<"\n$"<< dolEur << " dollars exchange to ";
    cout<< fixed << setprecision(2) << eurTot << " Euros." << endl;
            
    

    return 0;
}

