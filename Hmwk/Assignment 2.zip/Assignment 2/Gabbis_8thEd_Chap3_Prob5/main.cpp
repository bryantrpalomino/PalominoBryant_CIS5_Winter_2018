/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 9:50 PM
 * Purpose: Assignment 2 
 */

/* Write a program that asks the user for the number of males and the number 
 * of females registered in a class. The program should display the percentage
 * of males and females in the class.
 * Hint: Suppose there are 8 males and 12 females in a class. 
 * There are 20 students in the class. The percentage of males can be calculated
 * as 8 ÷ 20 = 0.4, or 40%. 
 * The percentage of females can be calculated as 12 ÷ 20 = 0.6, or 60%.
 */

#include <iostream>
#include <iomanip>
using namespace std;

int main() 
{
    //constant variables
    float males, females,totStd, malPrct,fPrct;

    //statements 
    cout<<"How many males are in the classroom? "<< endl;
    cin>>males;
    cout<<"How many females are in the classroom? "<< endl;
    cin>>females;
    
    totStd = males + females;               //Total amount of students in a classroom
    malPrct = (males / totStd) * 100;       //Percentage of males in classroom
    fPrct = (females / totStd) * 100;       //Percentage of females in classroom
    
    cout<< "The percentage of males in the classroom is: %"<< setprecision(3)<< malPrct<< endl; 
    cout<< "The percentage of females in the classroom is: %"<< setprecision(3)<< fPrct <<endl; 
    
    return 0;
}

