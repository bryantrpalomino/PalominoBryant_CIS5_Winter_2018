/*
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 8:13 PM
 * Purpose: Assignment 2
 */

/* Write a program that asks for five test scores. The program should
 * calculate the average test score and display it. The number displayed 
 * should be formatted in fixed-point notation, with one decimal point 
 * of precision.
 */

#include <iostream>
#include <iomanip>

using namespace std;

 
int main() 

{
    //variables 
    float score1,score2,score3,score4,score5,avg; 
    
    //statements for test scores 
    cout<<"Enter the score for the first exam: "<< endl; 
    cin>> score1;
    
    cout<<"Enter the score for the second exam: "<<endl; 
    cin>> score2; 
    
    cout<<"Enter the score for the third exam: "<<endl;
    cin>> score3;
    
    cout<<"Enter the score for the fourth exam: "<<endl; 
    cin>> score4;
    
    cout<<"Enter the score for the fifth exam: "<<endl;
    cin>> score5; 
    
    //Equation
    
    avg = (score1+score2+score3+score4+score5) / 5; 
    
    cout<<"Your average test score is: "<<endl;
    cout<< setprecision(1)<< fixed<<avg<< endl; 
   
   
    return 0;
}

