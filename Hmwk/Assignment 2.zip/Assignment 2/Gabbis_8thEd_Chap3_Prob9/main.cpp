/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 *Created on January 12, 2018,11:22PM
 * Purpose :Assignment 2
 */


#include <iostream>

using namespace std;

int main() 
{
    float cook, totCal;
  
    
    cout << "How many cookies did you eat? ";
    cin >> cook;                    //cook is cookies 
    
    
    //Equation
    totCal = cook * 100;            //total amount of calories 
    
    cout << "Your total calories for eating " << cook << " cookies is ";
    cout << totCal;

    return 0;
}

