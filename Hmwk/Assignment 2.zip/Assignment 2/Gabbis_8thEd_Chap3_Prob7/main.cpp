/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 10:12 PM
 * Purpose: Assignment 2 
 */


#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
    //Constants 
    string movie;
    float adult, child, totProf, groProf,disProf; 
    
    adult = 10;     //Ticket pricing for adult in dollars
    child = 6;      //Ticket pricing for children in dollars 
            
    
    //Statement 
    cout<< "Enter name of movie: " << endl;
    getline(cin,movie);
    
    cout<<"How many adult tickets were sold for "<< movie<< "?"<<endl;
    cin>>adult; 
    
    cout<<"How many children tickets were sold for "<<movie<< "?"<<endl;
    cin>>child; 
    
    groProf = adult + child;        // total gross amount of ticket sales of the movie 
    totProf = groProf * .80;        //total profit of movie theater is 20% of gross
    disProf = groProf * .20;        //Total profit made to the distributor 
    
    cout<< "Movie title:              "<<setw(6)<<movie<< endl;
    cout<< "Adult tickets sold:      "<<setw(6)<<"$"<<adult<< endl;
    cout<< "Children tickets sold:   "<< setw(6)<<"$"<<child<< endl;
    cout<< "Gross box office profit: "<<setw(6)<<"$"<<groProf << endl; 
    cout<< "Net box office profit:   "<<setw(6)<<"$"<<totProf << endl; 
    cout<< "Distributor profit:      "<<setw(6)<<"$"<< disProf <<endl;
    
    
    
    return 0;
}

