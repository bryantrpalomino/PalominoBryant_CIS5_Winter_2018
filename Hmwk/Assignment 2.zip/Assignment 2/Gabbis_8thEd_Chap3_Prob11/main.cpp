/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 *Created on January 12, 2018, 7:43 PM
 * Purpose: Assignment 2
 */


#include <iostream>
#include <iomanip>  
using namespace std;

int main() 
{
    //constants 
    float loanpayment, insurance, gas, oil, tires, maintenance, Monthlycost, Annualcost;
    
    //Statements and input
    cout << "Automobile Expenses" <<endl;
    
    cout << "\nHow much do you pay a month on your loan? "<<endl; 
    cin>>setw(8) >> loanpayment;
    
    cout <<  "How much you pay a month on insurance? "<<endl;
    cin>>setw(8)>> insurance;
    
    cout << "How much you pay a month on gas? "<<endl;
    cin>>setw(8) >> gas;
    
    cout << "How much you pay a month on oil? "<<endl;
    cin>>setw(8) >> oil;
    
    cout << "How much you pay a month on tires? "<<endl;
    cin>>setw(8)>> tires;
    
    cout << "How much you pay a month on maintenance? "<<endl;
    cin>>setw(8)>> maintenance;
    
    //Equation
    Monthlycost = loanpayment + insurance + gas + oil + tires + maintenance;
    
    Annualcost = Monthlycost * 12;
           
            
    cout << "Your monthly cost for your automobile is:" <<setw(8)<<"$"<<Monthlycost<<endl;
    
    cout << "Your annual cost for your automobile is:" <<setw(8)<< "$"<<Annualcost<< endl;
  

    return 0;
}
