/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 9:13 PM
 * Purpose: Assignment 2
 */

/* Write a program that calculates the average rainfall for three months. 
 * The program should ask the user to enter the name of each month, such 
 * as June or July, and the amount of rain (in inches) that fell each month.
 *  The program should display a message similar to the following:
 *  The average rainfall for June, July, and August is 6.72 inches.
 */
#include <iostream>
#include <iomanip>
using namespace std;


int main()
{
    //variable constants 
    string m1,m2,m3;
    
    float rain1,rain2,rain3,avg;
    
    //statements and identifiers 
    cout<<"Enter the names of the 3 months you wish to see the average rainfall."<<endl;
    cin>>m1;
    cout<<" "<<endl;
    cin>>m2;
    cout<<" "<<endl;
    cin>>m3;
    cout<<" "<<endl; 
    
    cout<<"enter the amount of rain for "<<m1<<" in inches:"<<endl;
    cin>>rain1;
    cout<<"enter the amount of rain for "<<m2<<" in inches:"<<endl;
    cin>>rain2;
    cout<<"enter the amount of rain for "<<m3<<" in inches:"<<endl;
    cin>>rain3;
    
    avg= (rain1 + rain2 +rain3 ) / 3 ; 
    
    cout<<"The average rain fall for these months is " <<setprecision(2)<< avg<< " inches" << endl;
    
    
    return 0;
}

