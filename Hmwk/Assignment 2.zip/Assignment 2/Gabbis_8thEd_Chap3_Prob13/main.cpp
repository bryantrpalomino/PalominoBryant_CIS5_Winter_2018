/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 6:34 PM
 * Purpose: Assignment 2 
 */


#include <iostream>
using namespace std;

int main() 
{
    float fah, cel;
    
    
    cout << "Enter the temperature in celsius that you would like to convert into Fahrenheit ";
    cin >> cel;
    
    //Equation
    fah = ((9 * cel)/5)+32;     //Conversion from celious to fahrenheit
    
    cout << "The temperature in Fahrenheit is ";
    cout << fah << endl;
   
    
    return 0;
}

