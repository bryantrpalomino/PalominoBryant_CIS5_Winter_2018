/* 
 * File:   main.cpp
 * Author: Bryan Palomino
 * Created on January 10, 2018, 1:29 PM
 * Purpose: Problem 2 
 */

/*
There are three seating categories at a stadium. For a softball game, Class A 
 * seats cost $15, Class B seats cost $12, and Class C seats cost $9. Write a 
 * program that asks how many tickets for each class of seats were sold, then 
 * displays the amount of income generated from ticket sales. Format your 
 * dollar amount in fixed-point notation, with two decimal places of precision,
 * and be sure the decimal point is always displayed.
 */

#include <iostream>

using namespace std;

int main() 
{
    float ClassA,ClassB,ClassC,QuantA,QuantB,QuantC,totA,totB,totC,totTot;
    
    ClassA = 15 ;   // Seating Class A value in Dollars.
    ClassB = 12 ;   // Seating Class B value in Dollars.
    ClassC = 9  ;   // Seating Class C value in Dollars. 
    
    cout<<"How many tickets were sold in class A seating?" << endl; 
    cin >> QuantA; 
    
    cout<<"How many tickets were sold in class B seating?" << endl;
    cin >> QuantB; 
    
    cout<<"How many tickets were sold in class C seating?" << endl; 
    cin >> QuantC; 
    
    totA = ClassA * QuantA ;    //Total amount of money made in class A seating. 
    totB = ClassB * QuantB ;    //Total amount of money made in class B seating. 
    totC = ClassC * QuantB ;    //Total amount of money made in class C seating.
    
    totTot = totA + totB + totC ; 
    
    cout<< "The total amount of income made with the ticket sales are $" << totTot << endl;
    
    
    return 0;
}

