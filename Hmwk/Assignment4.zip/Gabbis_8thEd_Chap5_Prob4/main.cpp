/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 8:08 PM
 * Purpose: Assignment 4
 */

#include <iostream>  

using namespace std;

int main()
{
    //Declare Variables
    float CalBPM=3.6,   //Calories burned per minute 
          TotCalB,      //Total Calories burned 
          Mins=5;       //Increments of 5 minutes 
            
    //Initialize Variables 
 
    CalBPM=3.6;     //Calories burned per minute 
    
    //Input and output data 
    cout<<"Calroies burnt every 5 minutes on a treadmill is... \n";
    cout<<"\nMinutes:\tCalories Burned:\n  ";
       
    for(Mins; Mins<=30; Mins+=5)
    {
        cout<<Mins;
        TotCalB= CalBPM * Mins;
        cout<<"\t        "<<TotCalB<<"\n ";
    }
            
    //Exit stage right. 
    return 0;
}


