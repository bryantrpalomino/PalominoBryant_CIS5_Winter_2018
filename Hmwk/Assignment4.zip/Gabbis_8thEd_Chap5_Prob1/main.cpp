/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 8:49 PM
 * Purpose: Assignment 4 
 */
#include <iostream>  
using namespace std;

int main()  
{
    //Declare Variables
    int sum=0, 
        num, // Number inputed 
        add;    
  
    //Initialize variables 
    cout<<"Enter a Positive Integer. ";
    cin>>num;
        
        //Input and output data 
        if (num<0)
            cout<<"This number could not be computed. ";
        else
        {
           
            for(add=0; add<=num; add++)
                sum+=add;
            cout<<"The sum of all the numbers from 0 to "<<num
            <<" is " <<sum;   
        }    
        
      
   
    //Exit stage right! 
    return 0;
}


