/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 10:19 PM
 * Purpose: Assignment 4
 */

#include <iostream>  

using namespace std;

int main() 
{
    //Declare variables
    float year,cost,percIn;
    
    //initialize variables 
    cost=2500,
    year=2018,
    percIn=.04;
           
    
    //Input and output data
    cout<<"See Chart for yearly membership fee.\n";
    cout<<"\nYear:\tFee Amount($):\n";
    
    for (year; year<=2024; year++)
    { 
        cout<<year;
        cost+=(cost*percIn);
        cout<<"       "<<cost<<"\n";
    }    
    

    return 0;
}
