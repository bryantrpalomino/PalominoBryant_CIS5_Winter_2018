/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 7:29 PM
 * Purpose: Assignment 4 
 * ***NOTICE:This problem was a collaborated effort.***
 */

#include <iostream>  
using namespace std;

int main()
{
    //Declare Variables 
    int hours,distnc,mph,loop;
    
    //Initialize Variables
    loop=1;    
    
    //Input and output data
    cout<<"What is the speed of the car (in miles per hour)? ";
    cin>>mph;
    cout<<"\n";
    cout<<"How many hours did the car travel for? ";
    cin>>hours;
    
    
    if(mph<0)
        cout<<"Your input was invalid for miles per hour.";

    else if (hours<1)
        cout<<"Your input was invalid for hours driven";
    else
    {
    
        cout<<"Hours:\tDistance traveled:\n";
       
        for(loop ; loop<=hours; loop++)
        {
           distnc=mph*loop;
           cout<<loop;
           cout<<"\t"<<distnc<<"\n";      
        }    
           
        
    }    
    //exit stage right!
    return 0;
}