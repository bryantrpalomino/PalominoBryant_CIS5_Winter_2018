/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 9:50 PM
 * Purpose: Assignment 4
 */

#include <iostream>
#include <iomanip>
using namespace std;

int main()  
{
    
    //Declare Variables
    float annIR,//Annual interest rate
          monthIR,//Monthly interest rate 
          startBal,//Starting balance in savings account
          mnthsPas;//Months that have passed since the account was established 
           
    //Input and output data
    cout<<"Please enter the annual interest rate.(Percentage)"<<endl;
    cin>>annIR;
    cout<<"Please enter the starting balance."<<endl; 
    cin>>startBal;
    cout<<"Please enter the number of months you want to calculate."<<endl;
    cin>>mnthsPas;
    
   
    annIR/=100.0f;          //Convert percent to decimal
    monthIR=annIR/12.0f;
   
    float moneyDep=0,       //Moneys deposited
          finBal=0,         //Balance at the end of the period of time
          intEarn=0,        //Interest the money has earned
          newBal=0,         //New balance
          totDep=0,         //Total amount deposited 
          totWit=0,         //Total amount withdrawn
          totIrate=0,       //Total interest earned
          moneyWit=0;       //Moneys withdrawn
    int month=1,num=1;
    
    
    do{
        
        cout<<"Enter money deposited for the month. "<<num<<endl;
        cin>>moneyDep;      //Money deposited into the account
        while(moneyDep<0){
            cout<<"Enter a valid amount deposited for the month. "<<num<<endl;
            cin>>moneyDep;
        }
        cout<<"Enter money withdrawn for the month. "<<num<<endl;
        cin>>moneyWit;//Money taken out of the account
        while(moneyWit<0){
            cout<<"Enter a valid amount withdrawn for the month. "<<num<<endl;
            cin>>moneyWit;
        }
        newBal=intEarn+startBal+moneyDep+totDep-totWit-moneyWit;    //Balance after monthly transactions
        intEarn=monthIR*newBal;                                     //Interest earned at the end of the month
        totIrate+=intEarn;                                          //Total amount of interest earned
        totDep+=moneyDep;                                           //Total amount deposited
        totWit+=moneyWit;                                           //Total amount withdrawn
        num++;
        month++;

    }while(month<=mnthsPas);
    finBal=totIrate+startBal+totDep-totWit;
    int pennies=finBal*100+0.5;//Round to the nearest penny
    finBal=pennies/100.0f;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Final balance in the account is $ "<<setw(6)<<finBal<<endl;
    cout<<"Total amount of withdrawals is  $ "<<setw(6)<<totWit<<endl;
    cout<<"Total amount of deposits is     $ "<<setw(6)<<totDep<<endl;
    cout<<"Total interest earned is        $ "<<setw(6)<<totIrate<<endl;
   
    return 0;
}
