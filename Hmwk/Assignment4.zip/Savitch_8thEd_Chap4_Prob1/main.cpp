/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 11:13 PM
 * Purpose: Assignment 4
 */

#include <iostream>
using namespace std;

int main()   
{
    //declare Variables 
    float liter,galGas;
    int miles,gasMil;
    
    cout<<"Input the number of liters your car consumes."<<endl;
    cin>>liter;
    cout<<"Input the number of miles you have driven."<<endl;
    cin>>miles;
    
    //Equations
    galGas=0.264*liter;
    gasMil=miles/galGas;
    
    //Output
    cout<<gasMil<<" Miles Per Gallon "<<endl;
    
    return 0;
}

