/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 10:13 PM
 * Purpose: Assignment 4
 */

#include <iostream> 
#include <iomanip>
using namespace std;

int main() 
{
    // Declare Variables
    float litGas,galGas,gasMil,secLit,sgalGas,sgasMil;
    int nMiles,secMil;


    //Input and output data 
    cout<<"Input the amount of liters the first car consumed."<<endl;
    cin>>litGas;
    cout<<"Input the number of miles the first car has driven."<<endl;
    cin>>nMiles;
    cout<<"Input the amount of liters the second car consumed."<<endl;
    cin>>secLit;
    cout<<"Input the number of miles the second car has driven."<<endl;
    cin>>secMil;
    
    galGas= 0.264* litGas;
    sgalGas= 0.264* secLit;
    gasMil= nMiles/ galGas;
    sgasMil= secMil/ sgalGas;
    
    if (gasMil>sgasMil)
        cout<<"The first car is the most fuel efficient."<<endl;
    else
        cout<<"The second car is the most fuel efficient."<<endl;
    
    
          
    
    //Output 
    cout<<fixed<<setprecision(2)<<showpoint<<endl;
    cout<<gasMil<<" Miles Per Gallon : First Car"<<endl;
    cout<<sgasMil<<" Miles Per Gallon : Second Car"<<endl;
    

    return 0;
}

