/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 22, 2018, 9:54 PM
 * Purpose: Assignment 4
 */

#include <iostream>  

using namespace std;

int main() 
{
    //Declare Variables
    int year;
    float totRis,risPY;
            
    year=2018;  //current year
    risPY=1.5;  //Water rising per year
    totRis=0;    //total amount of rising
    
    cout<<"The ocean level rising per year for 25 years. \n";
    cout<<"---------------------------------"<<endl;
    
    
    //Loop
    for (year; year<=2043; year++)
    {
        cout<< year;
        totRis+=risPY;
        cout<<"\t"<<totRis<<" \n";
       
    }    
           
    return 0;
}

