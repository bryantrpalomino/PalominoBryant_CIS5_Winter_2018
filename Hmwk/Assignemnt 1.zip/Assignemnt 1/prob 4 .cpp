 /* File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 5, 2018, 11:41 PM
 * Assignment 1
 */

// Problem 4 from Gabbis textbook
//Write a program that computes the tax and tip on a restaurant bill for a 
//patron with a $88.67 meal charge. The tax should be 6.75 percent of the
//meal cost. The tip should be 20 percent of the total after adding the tax. 
//Display the meal cost, tax amount, tip amount, and total bill on the screen.


#include <iostream>
using namespace std;

int main() 
{
    float meal, tax, mealTax, totTax, tipAmount ,tip,  totCost;
    
    meal = 88.67 ;  // meal in Dollars 
    tax = 0.0675 ;  // tax percentage 
    tip = 0.2 ;     // tip percentage 
    
    totTax = meal * tax ; 
    tipAmount = meal * tip;
    totCost = totTax + tipAmount + meal ; 
    
    cout << "meal cost $" << meal << endl; 
    cout << "tax amount $" << totTax << endl; 
    cout << "tip amount $" << tipAmount << endl; 
    cout << "Total price of meal is $" << totCost << endl; 
    

    return 0; 
}
