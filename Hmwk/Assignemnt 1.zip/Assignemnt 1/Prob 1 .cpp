/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 5, 2018, 10:46 PM
 * Purpose : Assignment 1 
 */


// Problem 1 from Gabbis textbook 
//Sum of Two Numbers
//Write a program that stores the integers 50 and 100 in variables, 
//and stores the sum of these two in a variable named total.

#include <iostream>
using namespace std;
        
int main()
{
    float fifty, oneHundred, sum;
    
    fifty = 50 ; 
    oneHundred = 100;

    sum = fifty + oneHundred ; 
    
    cout << sum << endl; 
       
              
    return 0;
    
}





