/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 5, 2018, 11:25 PM
 * Purpose: Assignment 1 
 */

//Problem 3 from Gabbis textbook. 
//Write a program that will compute the total sales tax on a $95 purchase. 
//Assume the state sales tax is 4 percent and the county sales tax is 2 percent.

#include <iostream>
using namespace std; 

int main() 
{
    float purchase,item, stTax, countyTax, totTax;  
    
    item = 95.0;    // in dollars 
    stTax = 0.04;   // percentage for state tax 
    countyTax = 0.02; // percentage for county tax 
    
    
    totTax = (stTax + countyTax) * item ; 
    purchase = item + totTax ; 
           
    
    cout << "Total price of purchase is $" << purchase << endl; 
    
    return 0;
}