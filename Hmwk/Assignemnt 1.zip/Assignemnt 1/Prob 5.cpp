/* 
 * File:   main.cpp
 * Author: bryantpalomino
 * Created on January 5, 2018, 11:58 PM
 * Purpose : Assignment 1
 */


//Problem 5 from Dabbis textbopk.
//To get the average of a series of values, you add the values up and then 
//divide the sum by the number of values. Write a program that stores the 
//following values in five different variables: 28, 32, 37, 24, and 33. 
//The program should first calculate the sum of these five variables and 
//store the result in a separate variable named sum. Then, the program 
//should divide the sum variable by 5 to get the average. Display the 
//average on the screen.

#include <iostream>
using namespace std; 

int main() 
{
    float one, two, three, four, tot, variables,  sum; 
    
    one = 28 ; 
    two = 32 ; 
    three = 24 ; 
    four = 33 ; 
    variables = 5 ; 
    
    sum = one + two + three + four ; 
    
    tot = sum / variables ; 
    
    cout << "the average for these values are " << tot << endl; 
    
    
    return 0;
}
