/*
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 6, 2018, 12:48 AM
 * Purpose : Assignment 1 
 */

// Problem 8 from Gabbis textbook
//A customer in a store is purchasing five items. The prices of the five items are
//Price of item 1 = $15.95 
////Price of item 2 = $24.95 
//Price of item 3 = $6.95 
//Price of item 4 = $12.95 
//Price of item 5 = $3.95
//Write a program that holds the prices of the five items in five variables. 
//Display each item’s price, the subtotal of the sale, the amount of sales tax, 
//and the total. Assume the sales tax is 7%.

#include <iostream>
using namespace std; 

int main()
{
    float itemOne, itemTwo, itemThree, itemFour, itemFive, tax, subTotal, totTax, total; 
    
    itemOne     = 15.95;    // in dollars 
    itemTwo     = 24.95;    // in dollars 
    itemThree   = 6.95;     // in dollars 
    itemFour    = 12.95;    // in dollars
    itemFive    = 3.95;     // in dollars 
    tax         = 0.07;     // sales tax 
    
    subTotal = itemOne + itemTwo + itemThree + itemFour + itemFive; 
    totTax = subTotal * tax ; 
    total = totTax + subTotal; 
    
    cout << "item 1 $" << itemOne << endl; 
    cout << "item 2 $" << itemTwo << endl; 
    cout << "item 3 $" << itemThree << endl; 
    cout << "item 4 $" << itemFour << endl; 
    cout << "item 5 $" << itemFive << endl; 
    cout << "Subtotal $" << subTotal << endl; 
    cout << "Sales tax of 7% of purchase $" << totTax << endl; 
    cout << "Total $" << total << endl;
    
            
    return 0;
}