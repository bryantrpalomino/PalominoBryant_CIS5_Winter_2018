/*
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 6, 2018, 12:17 AM
 * Purpose : Assignment 1 
 */

// Problem 7 from Gabbis textbook
//Assuming the ocean’s level is currently rising at about 1.5 millimeters 
//per year, write a program that displays:
//1.    The number of millimeters higher than the current level that the 
//      ocean’s level will be in 5 years
//2.    The number of millimeters higher than the current level that the 
//      ocean’s level will be in 7 years
//3.    The number of millimeters higher than the current level that the 
//      ocean’s level will be in 10 years

#include <iostream>
using namespace std; 

int main() 
{
    float rate, yearFive, yearSeven, yearTen; 
    
    rate = 1.5 ; // In millimeters 
    
    yearFive = rate * 5; 
    yearSeven = rate *7; 
    yearTen = rate * 10; 
    
    cout << "In 5 years the ocean will have risen by " << yearFive << " millimeters." << endl; 
    cout << "In 7 years the ocean will have risen by " << yearSeven << " millimeters." << endl; 
    cout << "In 10 years the ocean will have risen by " << yearTen << " millimeters." << endl; 
    
    return 0;
}