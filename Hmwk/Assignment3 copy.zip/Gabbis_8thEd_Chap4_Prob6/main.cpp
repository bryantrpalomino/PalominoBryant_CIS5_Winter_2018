/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 17, 2018, 11:18 PM
 * Purpose: Assignment 3 
 */

/* Scientists measure an object’s mass in kilograms and its weight 
 * in newtons. If you know the amount of mass that an object has, you can 
 * calculate its weight, in newtons, with the following formula:
 * Weight = mass  * 9.8
 * Write a program that asks the user to enter an object’s mass, and then 
 * calculates and displays its weight. If the object weighs more than 1,000 
 * newtons, display a message indicating that it is too heavy. If the object 
 * weighs less than 10 newtons, display a message indicating that the object 
 * is too light.
 */
#include <iostream>

using namespace std;

int main() 
{
    //Declare variables 
    float weight, mass; 
    
    //Initialize variables
    cout<<"Enter an object's mass (In kilograms) : "<<endl; 
    cin>>mass; 
    
    weight=mass*(9.8);      //Weight measured in Newton's and mass measured
                            //in kilograms 
    
    if(weight>1000)
        cout<< "WOW! That object is really heavy!"<<endl; 
    if(weight<10)
        cout<< "This object is too light"<< endl; 
    else if (weight)
        cout<< "This object weighs "<<weight<< " newtons"<<endl;
   
    
    return 0;
}

