/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 17, 2018, 1:35 PM
 * Purpose: Assignment 3
 */

/*Create a change-counting game that gets the user to enter the 
 * number of coins required to make exactly one dollar. The program 
 * should ask the user to enter the number of pennies, nickels, dimes, 
 * and quarters. If the total value of the coins entered is equal to one 
 * dollar, the program should congratulate the user for winning the game. 
 * Otherwise, the program should display a message indicating whether the 
 * amount entered was more than or less than one dollar.
 */

#include <iostream> 
using namespace std;

int main() 
{
    //Declare Variables 
    float quartrs, dimes, nickls, pennies, Sum;
   
    //Initializer Variables 
    cout<< "Enter the number of quarters "<<endl;
    cin>> quartrs;
    cout<< "Enter the number of dimes "<<endl;
    cin>> dimes;
    cout<<"Enter the number of nickels "<<endl;
    cin>> nickls;
    cout<< "Enter the number of pennies "<<endl;
    cin>> pennies;

    
    Sum=(quartrs*.25)+(dimes *.10)+(nickls*.05)+(pennies*.01);  //Sum of total amount.
    
    //Process inputs and outputs 
    if (Sum == 1)
        cout<< "Your amount is correct.";
    
    if (Sum > 1)
        cout<< "The amount is more than one dollar.";
    
    if (Sum < 1)
        cout<< "The amount is less than one dollar.";
            
            
    return 0;
}
