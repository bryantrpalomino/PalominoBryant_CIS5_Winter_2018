/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 17, 2018, 10:40 PM
 * Purpose: Assignment 3
 */

/* The area of a rectangle is the rectangle’s length times its width. 
 * Write a program that asks for the length and width of two rectangles. 
 * The program should tell the user which rectangle has the greater area, or 
 * if the areas are the same.
 */

#include <iostream>

using namespace std;


int main() 
{
    //declare variables 
    float length1, length2, width1,
          width2, area1, area2;
    
    //Initialize variables 
    cout<<"What is the length of the first rectangle?"<<endl; 
    cin>>length1;
    cout<<"What is the width of the first rectangle?"<<endl; 
    cin>>width1;
    cout<<"What is the length of the second rectangle?"<<endl;
    cin>>length2;
    cout<<"What is the width of the second rectangle?"<<endl; 
    cin>>width2; 
    
    
    area1=length1*width1;           //Area of first rectangle 
    area2=length2*width2;           //Area of second rectangle
    
    //Initializing inputs and outputs 
    if (area1>area2)
        cout<<"\nThe first rectangle has the bigger area."<<endl;
    if (area2>area1)
        cout<<"\nThe second rectangle has the bigger area."<<endl; 
    if (area1=area2)
        cout<<"\nBoth areas are the same."<<endl;
    
    return 0;
}

