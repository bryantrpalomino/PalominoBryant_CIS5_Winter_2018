/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 17, 2018, 9:31 PM
 * Purpose: Assignment 3 
 */

/* Write a program that asks the user to enter a number within the range of 1 
 * through 10. Use a switch statement to display the Roman numeral version
 * of that number. Input Validation: Do not accept a number less than 1 or
 * greater than 10.
 */

#include <iostream>

using namespace std;


int main() 
{
    //declare variables
    int num;
    
    //initialize variables
    cout<<"Enter a number between 1 through 10" <<endl;
    cout<<"and I will display it in Roman numerals. "<<endl; 
    cin>>num;
   
   //input and output data
    switch (num)
    {
        case 1 : cout<<"---\nI"<<endl;
                break;
                
        case 2 : cout<<"---\nII"<<endl;
                break;
                
        case 3 : cout<<"---\nIII"<<endl;
                break;
                
        case 4 : cout<<"---\nIV"<<endl; 
                break;
                
        case 5 : cout<<"---\nV"<<endl; 
                break;
                
        case 6 : cout<<"---\nVI"<<endl;
                break;
                
        case 7 : cout<<"---\nVII"<<endl; 
                break;
                
        case 8 : cout<<"----\nVIII"<<endl;
                break;
                
        case 9 : cout<<"---\nIX"<<endl; 
                break;
        
        case 10 : cout<<"---\nX"<<endl; 
                break;
        
        default: cout<<"----------------------------\nIm sorry, but your entry was\ninvalid."<<endl;
    }
    
    
    return 0;
}

