/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 12, 2018, 5:14 PM
 * Purpose: Assignment 3
 */

/*Write a program that asks the user to enter a number of seconds.
• There are 60 seconds in a minute. If the number of seconds entered by 
 * the user is greater than or equal to 60, the program should display the 
 * number of minutes in that many seconds.
• There are 3,600 seconds in an hour. If the number of seconds entered by
 *  the user is greater than or equal to 3,600, the program should display 
 * the number of hours in that many seconds.
• There are 86,400 seconds in a day. If the number of seconds entered by 
 * the user is greater than or equal to 86,400, the program should display 
 * the number of days in that many seconds.
 */

#include <iostream> 
using namespace std;

int main()
{
    //declare variables
    float hrs,sec,min,days;
    
    //Initializing variables 
    cout<<"Please Enter number of seconds "<<endl;
    cin>>sec;
    
    min = sec/60;       //minutes convert to seconds
    hrs = sec/3600;     //hours convert to seconds
    days = sec/86400;   //days convert to seconds 
    
   
    //Process inputs and outputs 
    if (sec >= 60&& sec<360)
        cout <<"The number of minutes in the seconds are "<<min<<endl;
    
    if (sec>= 3600&& sec<86400)
        cout << "The number of hours in the seconds are "<<hrs<<endl;
    
    if (sec>=86400)
       cout << "The number of days in the seconds you are "<< days<<endl;
    
    return 0;
}