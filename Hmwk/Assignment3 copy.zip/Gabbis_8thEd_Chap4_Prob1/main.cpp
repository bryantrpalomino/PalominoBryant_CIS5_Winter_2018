/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 17, 2018, 9:00 PM
 * Purpose: Assignment 3
 */

/* Write a program that asks the user to enter two numbers. The program 
 * should use the conditional operator to determine which number is the 
 * smaller and which is the larger.
 */
#include <iostream>
#include <iomanip>

using namespace std;


int main() 
{
    //Declare variables 
    float num1,     //Number one 
          num2;     //Number two 
    
    //Initialize variables 
    cout<<"Enter two numbers: "<<endl; 
    cin>>num1>>num2;
    
    //inputs and outputs 
    if (num1>num2)
        cout<<num1<<" is larger and "<<num2<< " is the smaller number"<<endl; 
    else  
        cout<<num2<<" is larger and "<<num1<< " is the smaller number"<<endl; 
    
    
    return 0;
}

