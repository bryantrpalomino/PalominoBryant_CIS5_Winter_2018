/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 18, 2018, 8:43 PM
 * Purpose: Lab Assignment 5
 */

#include <iostream>

using namespace std;


int main() 
{
    //Declare Variables
    float payRate,hrsWrkd,payChck,dblPay; 
    
    //Initialize Variables 
    cout<<"How many is your hourly pay rate?"<<endl;
    cin>>payRate;
    cout<<"How many hours have your worked this week?"<<endl;
    cin>>hrsWrkd; 
    
   
    //Input and out data 
    if (hrsWrkd<0)
        cout<<"Invalid entry!"<<endl; 
    if (hrsWrkd<=40)
        cout<<"Your total paycheck will be: $"<<hrsWrkd*payRate<<endl; 
    if (hrsWrkd>40)
        cout<<"Your total paycheck will be: $"<<(((hrsWrkd-40)*(payRate*2))+(40*payRate))<<endl; 
            
    
    return 0;
}

