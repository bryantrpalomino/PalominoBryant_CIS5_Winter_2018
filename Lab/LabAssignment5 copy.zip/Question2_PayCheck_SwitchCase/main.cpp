/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 18, 2018, 9:35 PM
 * Purpose: Lab assignment 5
 */

#include <iostream>

using namespace std;

int main() 
{
    //Declare Variables 
    float hrsWrkd,payRate,payChck,dblPay; 
    char aorb;
    
    //Initialize Variables 
    cout<<"How many is your hourly pay rate?"<<endl;
    cin>>payRate;
    cout<<"Please enter the amount of hours worked"<<endl;
    cin>>hrsWrkd;
    
    
    if (hrsWrkd<0)
        cout<<"Invalid entry!"<<endl; 
   
    
    //Input and output data 
    cout<<"Enter (a) if hours worked are less then 40 "<<
           "or pick (b) if hours worked is more than 40"<<endl; 
    cin>>aorb; 
    
    switch (aorb)
    {
        case 'a' : cout<<"Enter total hours worked this week is: $"<<payRate*hrsWrkd<<endl;
            break;
        case 'b' : cout<<"Enter total hours worked this week is: $"<<(((hrsWrkd-40)*(payRate*2))+(40*payRate))<<endl; 
            break;
        default  : cout<<"You did not enter (a) or (b)."<<endl; 
    }
           
    
    return 0;
}

