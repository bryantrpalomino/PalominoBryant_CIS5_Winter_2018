/* 
 * File:   main.cpp
 * Author: Bryant Palomino
 * Created on January 18, 2018, 10:18 PM
 * Purpose: Lab Assignment 5
 */



#include <iostream>

using namespace std;

int main() 
{
    //Declare variables 
    float hrsWrkd,payRate,payChck,
          case1,case2,answer;
    
    
    //Initialize variables
    cout<<"How many is your hourly pay rate?"<<endl;
    cin>>payRate;
    cout<<"How many hours did you work this week?"<<endl;
    cin>>hrsWrkd;
    
    
    //Input and output data
    if (hrsWrkd<0)
        cout<<"Invalid entry!"<<endl;      
    
    case1=payRate*hrsWrkd;
    case2=(((hrsWrkd-40)*(2*payRate))+(payRate*40));
    
    answer=(hrsWrkd>=0 && hrsWrkd<=40)? case1 : case2;
         
    cout<<"Your total paycheck for this week is: $"<<answer<<endl; 
    
    
    return 0;
}

